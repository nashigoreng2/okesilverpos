<?php
mysql_connect('localhost','root','');
mysql_select_db('okesilverpos');

if (isset($_GET['page']) == 'data_barang')
{
echo "<form action='action_insert.php' method='post'>
<table border='0'>
<tr>
<td>Id</td>
</tr>
</table>
</form>";
}
?>
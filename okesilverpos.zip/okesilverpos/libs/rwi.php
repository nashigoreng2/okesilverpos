

<?php

class rwi {

	function db($db) {

		$this->db = $db;

	}

	function login($userid,$userpass) {

		$sql = "SELECT * FROM user WHERE kode_user = '%s' and password = '%s'" limit 1;

		$sql = sprintf($sql,md5($userid),$userpass);

		$result = mysqli_query($sql);

		$ret = 'ERROR';

		if ($result) {
			
			while ($data = mysqli_fetch_array($result)) {

				$_SESSION[rwi][myid] = $data['kode_user'];

				$_SESSION[rwi][username] = $data['username'];

				$_SESSION[rwi][email] = $data['email'];

				$_SESSION[rwi][nama] = $data['nama'];

			}

			$ret = 'OK';
		}

		return $ret;

	}

	function sendemails($to,$from,$subject,$message) {

		$headers = "MIME-Version: 1.0\r\nContent-type: text/html; charset=iso-8859-1\r\n";

		$headers = "From: " . $from . " \r\n";

		$headers = "Reply-To: " .  $from . "\r\n";

		mail($to, $subject, $message, $headers);

	}

	function generateKodeUser() {



	}

	function generateKodeCustomer() {



	}

}